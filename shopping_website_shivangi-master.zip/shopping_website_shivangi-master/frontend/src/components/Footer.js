import React from 'react'

const Footer = () => {
  return (
    <div className='footer' style={{ lineHeight: '8px' }}>
      <span style={{ padding: '10px' }}>
        Designed with{' '}
        <span
          style={{
            color: 'red',
            fontSize: '20px',
            textAlign: 'center',
            // marginTop:"50px"
          }}
        >
          {' '}
          <i class='fas fa-heart'></i>{' '}
        </span>{' '}
        by Shivangi Pandey
      </span>
      <span>
        {' '}
        <span style={{ fontSize: '24px' }}>
          <i class='far fa-copyright'></i>
        </span>{' '}
        Copyright {new Date().getFullYear()}
      </span>
      <span>All Rights Reserved</span>
    </div>
  )
}

export default Footer
